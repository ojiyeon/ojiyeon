package com.example.subin.myapplication;

import android.app.Activity;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;


public class AddFragment extends DialogFragment implements View.OnClickListener {

    ImageView ok, cancel;
    EditText positions, size;

    public AddFragment() {
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {

        }
        catch(ClassCastException e) {
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add, container);
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);

        size = (EditText)view.findViewById(R.id.size);
        positions = (EditText)view.findViewById(R.id.position);
        ok = (ImageView)view.findViewById(R.id.ok);
        ok.setOnClickListener(this);
        cancel = (ImageView)view.findViewById(R.id.cancel);
        cancel.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        int getId = v.getId();

        switch (getId){
            case R.id.ok:
                MainActivity.mAdapter.addItem(positions.getText().toString(), size.getText().toString());
                MainActivity.mAdapter.notifyDataSetChanged();
                dismiss();
                break;
            case R.id.cancel:
                dismiss();
                break;
        }
    }
}