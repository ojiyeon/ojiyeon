package com.example.subin.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;


public class MainActivity extends Activity {

    ImageView add, remove;
    private ListView mListView = null;
    public static GarbageAdapter mAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView = (ListView) findViewById(R.id.mList);

        add = (ImageView) findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AddFragment().show(getFragmentManager(), "ADD");
            }
        });
        remove = (ImageView) findViewById(R.id.remove);
        mAdapter = new GarbageAdapter(this);
        mListView.setAdapter(mAdapter);
        mAdapter.addItem("1층 입구", "100cm");

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Intent intent = new Intent(MainActivity.this,   GarbageCan.class);
                startActivity(intent);
            }
        });
    }
}
