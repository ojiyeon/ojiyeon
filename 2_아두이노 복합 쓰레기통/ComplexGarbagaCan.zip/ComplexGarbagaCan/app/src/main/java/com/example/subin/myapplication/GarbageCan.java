package com.example.subin.myapplication;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class GarbageCan extends Activity {

    Button Connect;
    TextView Result, Device;

    int[] idArray = {R.id.bar1, R.id.bar2, R.id.bar3, R.id.bar4, R.id.bar5, R.id.bar6, R.id.bar7, R.id.bar8, R.id.bar9, R.id.bar10};
    TextView[] tvArray =  new TextView[10];

    private static final String TAG = "Bluetooth";
    private BluetoothAdapter mBluetoothAdapter = null;
    private BluetoothSocket btSocket = null;
    private OutputStream outStream = null;
    private static String address = "20:14:08:14:22:84";
    private static final UUID MY_UUID = UUID
            .fromString("00001101-0000-1000-8000-00805F9B34FB");
    private InputStream inStream = null;
    Handler handler = new Handler();
    byte delimiter = 10;
    boolean stopWorker = false;
    int readBufferPosition = 0;
    byte[] readBuffer = new byte[1024];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garbagecan);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        //Connect = (Button) findViewById(R.id.connect);
        Result = (TextView) findViewById(R.id.result);
        Device = (TextView)findViewById(R.id.textView1);
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);

        for(int i = 0 ; i < tvArray.length; i++){
            tvArray[i] = (TextView)findViewById(idArray[i]);
        }
        Connect();
    }

    public void Connect() {
        Log.d(TAG, address);
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        Log.d(TAG, "Connecting to ... " + device);
        Device.setText(mBluetoothAdapter.getRemoteDevice(address).getName());

        mBluetoothAdapter.cancelDiscovery();
        try {
            btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
            btSocket.connect();
            Log.d(TAG, "Connection made.");
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {
                Log.d(TAG, "Unable to end the connection");
            }
            Log.d(TAG, "Socket creation failed");
        }

        beginListenForData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if(mBluetoothAdapter.isEnabled())
               btSocket.close();
        } catch (IOException e) {
        }
    }

   /* protected void onResume(){
        super.onResume();
        Intent intent = new Intent(MainActivity.this, BaseService.class);
        stopService(intent);
    }

    protected void onPause(){
        super.onPause();
        Intent intent = new Intent(MainActivity.this, BaseService.class);
        startService(intent);
    }*/

    public void beginListenForData()   {
        try {
            inStream = btSocket.getInputStream();
        } catch (IOException e) {
        }

        Thread workerThread = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopWorker)
                {
                    try
                    {
                        int bytesAvailable = inStream.available();
                        if(bytesAvailable > 0)
                        {
                            byte[] packetBytes = new byte[bytesAvailable];
                            inStream.read(packetBytes);
                            for(int i=0;i<bytesAvailable;i++)
                            {
                                byte b = packetBytes[i];
                                if(b == delimiter)
                                {
                                    byte[] encodedBytes = new byte[readBufferPosition];
                                    System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);
                                    final String data = new String(encodedBytes, "US-ASCII");
                                    readBufferPosition = 0;
                                    handler.post(new Runnable()
                                    {
                                        public void run()
                                        {
                                            int gage = Integer.parseInt(data.trim());
                                            if(gage >= 90 && gage <= 100){
                                                background(10);
                                            }else if(80 <= gage && gage <90){
                                                background(9);
                                            }else if(70 <= gage && gage <80){
                                                background(8);
                                            }else if(60 <= gage && gage <70){
                                                background(7);
                                            }else if(50 <= gage && gage <60){
                                                background(6);
                                            }else if(40 <= gage && gage <50){
                                                background(5);
                                            }else if(30 <= gage && gage <40){
                                                background(4);
                                            }else if(20 <= gage && gage <30){
                                                background(3);
                                            }else if(10 <= gage && gage <20){
                                                background(2);
                                            }else if(0 <= gage && gage <10){
                                                background(1);
                                            }
                                            Result.setText(data + "\n");
                                        }
                                    });
                                }
                                else
                                {
                                    readBuffer[readBufferPosition++] = b;
                                }
                            }
                        }
                    }
                    catch (IOException ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }

    void background(int a){
        a = a-1;

        for(int i=a; i<tvArray.length; i++){
            tvArray[i].setBackgroundColor(Color.rgb(33,56,78));
        }

        for(int i=0; i<a; i++){
            tvArray[i].setBackgroundColor(Color.WHITE);
        }
    }
}
