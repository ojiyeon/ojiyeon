package bean;

public class SubjectBean {
	private int subj_code;
	private String subj_state;
	private int subj_majorcode;
	private String subj_majorname;
	private String subj_name;
	private int subj_hakjum;
	private int subj_pro;
	private String subj_proname;
	private String subj_room;
	private String subj_day1;
	private String subj_day2;
	
	public int getSubj_code() {
		return subj_code;
	}
	public void setSubj_code(int subj_code) {
		this.subj_code = subj_code;
	}
	public String getSubj_state() {
		return subj_state;
	}
	public void setSubj_state(String subj_state) {
		this.subj_state = subj_state;
	}
	public int getSubj_majorcode() {
		return subj_majorcode;
	}
	public void setSubj_majorcode(int subj_majorcode) {
		this.subj_majorcode = subj_majorcode;
	}
	public String getSubj_majorname() {
		return subj_majorname;
	}
	public void setSubj_majorname(String subj_majorname) {
		this.subj_majorname = subj_majorname;
	}
	public String getSubj_name() {
		return subj_name;
	}
	public void setSubj_name(String subj_name) {
		this.subj_name = subj_name;
	}
	public int getSubj_hakjum() {
		return subj_hakjum;
	}
	public void setSubj_hakjum(int subj_hakjum) {
		this.subj_hakjum = subj_hakjum;
	}
	public int getSubj_pro() {
		return subj_pro;
	}
	public void setSubj_pro(int subj_pro) {
		this.subj_pro = subj_pro;
	}
	public String getSubj_proname() {
		return subj_proname;
	}
	public void setSubj_proname(String subj_proname) {
		this.subj_proname = subj_proname;
	}
	public String getSubj_room() {
		return subj_room;
	}
	public void setSubj_room(String subj_room) {
		this.subj_room = subj_room;
	}
	public String getSubj_day1() {
		return subj_day1;
	}
	public void setSubj_day1(String subj_day1) {
		this.subj_day1 = subj_day1;
	}
	public String getSubj_day2() {
		return subj_day2;
	}
	public void setSubj_day2(String subj_day2) {
		this.subj_day2 = subj_day2;
	}
}
