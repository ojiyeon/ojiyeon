package bean;

public class ScoreBean {
	
}
