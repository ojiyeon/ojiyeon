package schedule;

public class ScheduleBean {
	/*private int sche_num;*/
	private String sche_content;
	private int shce_startyear;
	private int shce_startmonth;
	private int shce_startday;
	private int shce_endyear;
	private int shce_endmonth;
	private int shce_endday;
	private int shce_holiday;
	public String getSche_content() {
		return sche_content;
	}
	public void setSche_content(String sche_content) {
		this.sche_content = sche_content;
	}
	public int getShce_startyear() {
		return shce_startyear;
	}
	public void setShce_startyear(int shce_startyear) {
		this.shce_startyear = shce_startyear;
	}
	public int getShce_startmonth() {
		return shce_startmonth;
	}
	public void setShce_startmonth(int shce_startmonth) {
		this.shce_startmonth = shce_startmonth;
	}
	public int getShce_startday() {
		return shce_startday;
	}
	public void setShce_startday(int shce_startday) {
		this.shce_startday = shce_startday;
	}
	public int getShce_endyear() {
		return shce_endyear;
	}
	public void setShce_endyear(int shce_endyear) {
		this.shce_endyear = shce_endyear;
	}
	public int getShce_endmonth() {
		return shce_endmonth;
	}
	public void setShce_endmonth(int shce_endmonth) {
		this.shce_endmonth = shce_endmonth;
	}
	public int getShce_endday() {
		return shce_endday;
	}
	public void setShce_endday(int shce_endday) {
		this.shce_endday = shce_endday;
	}
	public int getShce_holiday() {
		return shce_holiday;
	}
	public void setShce_holiday(int shce_holiday) {
		this.shce_holiday = shce_holiday;
	}
	
	
}
