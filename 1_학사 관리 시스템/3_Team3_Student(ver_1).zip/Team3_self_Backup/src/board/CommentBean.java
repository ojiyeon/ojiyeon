package board;

import java.sql.Timestamp;

public class CommentBean {
	
	private int cmt_index; // �Խñ� ������ȣ
	private int cmt_num; // ��� ��ȣ
	private String cmt_writer; // ��� �ۼ���
	private String cmt_content; // ��� ����
	private Timestamp cmt_date; // �ۼ���
	private String date2;
	private int cmt_stu_id; // �й�
	
	public CommentBean() {}
	
	// �Ű����� �ִ� ������ �߰�
	public CommentBean(int cmt_index, String cmt_writer, String cmt_content, Timestamp cmt_date,
			int cmt_stu_id) {
		this.cmt_index = cmt_index;
		this.cmt_writer = cmt_writer;
		this.cmt_content = cmt_content;
		this.cmt_date = cmt_date;
		this.cmt_stu_id = cmt_stu_id;
	}

	
	public int getCmt_index() {
		return cmt_index;
	}
	public void setCmt_index(int cmt_index) {
		this.cmt_index = cmt_index;
	}

	public int getCmt_num() {
		return cmt_num;
	}
	public void setCmt_num(int cmt_num) {
		this.cmt_num = cmt_num;
	}
	public String getCmt_writer() {
		return cmt_writer;
	}
	public void setCmt_writer(String cmt_writer) {
		this.cmt_writer = cmt_writer;
	}
	public String getCmt_content() {
		return cmt_content;
	}
	public void setCmt_content(String cmt_content) {
		this.cmt_content = cmt_content;
	}
	public Timestamp getCmt_date() {
		return cmt_date;
	}
	public void setCmt_date(Timestamp cmt_date) {
		this.cmt_date = cmt_date;
	}
	public String getDate2() {
		return date2;
	}
	public void setDate2(String date2) {
		this.date2 = date2;
	}
	public int getCmt_stu_id() {
		return cmt_stu_id;
	}
	public void setCmt_stu_id(int cmt_stu_id) {
		this.cmt_stu_id = cmt_stu_id;
	}
	
	
	

}
