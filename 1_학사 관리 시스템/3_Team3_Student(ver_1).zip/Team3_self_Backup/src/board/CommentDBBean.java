package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class CommentDBBean {

	private static CommentDBBean instance = new CommentDBBean(); // ��ü ����

	public static CommentDBBean getInstance() { // getInstance()ȣ�� �� CommentDBBean�� �����ϴ� ��ü ����
		return instance;
	}

	public Connection getConnection() throws Exception { // db �����ϴ� �޼ҵ�

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");
		Connection conn = ds.getConnection();
		return conn;
	}
	

	// ��� �Է�
	public int insertComment(CommentBean comment) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";
		int num = 0;
		int re = -1;
	

		try {
			con = getConnection();
			
			sql = "select max(cmt_num) from comments where cmt_index=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, comment.getCmt_index());

			rs = pstmt.executeQuery();

			if (rs.next()) { // null�� �ƴϸ�
				num = rs.getInt(1) + 1; // ���⼭ (1)�� �÷� �ε���

			} else {
				num = 1;
				rs.getInt(2);
			}
			pstmt.close();
			rs.close();


			// ������ ������ ���� ��, ��۹�ȣ ���� ū ���� +1 ���� ���� �����Ͽ� ��� �Է� �� ����
			sql = "insert into comments (cmt_index, cmt_num, cmt_writer, cmt_content, cmt_date, cmt_stu_id) values (?, ?, ?, ?, ?, ?)";

			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, comment.getCmt_index());
			pstmt.setInt(2, num);
			pstmt.setString(3, comment.getCmt_writer());
			pstmt.setString(4, comment.getCmt_content());
			pstmt.setTimestamp(5, comment.getCmt_date());
			pstmt.setInt(6, comment.getCmt_stu_id());

			re = pstmt.executeUpdate();

			pstmt.close();

			System.out.println(re);
			System.out.println("�߰� ����");

		} catch (Exception e) {
			System.out.println("�߰� ����");
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}

	// �Խù� ��ȣ�� �ش��ϴ� ��� ���
	public ArrayList<CommentBean> getListComment(int cmt_index) { // ���׸��� �����Ķ���� ����� ��

			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			ArrayList<CommentBean> commentList = new ArrayList<CommentBean>();

			String sql = "";

			try {
				con = getConnection();


				sql = "select * from (select a.*, to_char(cmt_date,'YYYY-MM-DD hh24:mi') date2 from comments a order by cmt_num) where cmt_index=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, cmt_index);
				
			
				rs = pstmt.executeQuery();

				while (rs.next()) {

					CommentBean comment = new CommentBean();
					
					comment.setCmt_index(rs.getInt(1));
					comment.setCmt_num(rs.getInt(2));
					comment.setCmt_writer(rs.getString(3));
					comment.setCmt_content(rs.getString(4));
					comment.setCmt_date(rs.getTimestamp(5));
					comment.setCmt_stu_id(rs.getInt(6));
					comment.setDate2(rs.getString(7));
					
					commentList.add(comment);
					
					
				}

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("��ȸ ����");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (pstmt != null) {
						pstmt.close();
					}
					if (con != null) {
						con.close();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			return commentList;
		}
	
	// ��� ���� ���
	public int getCountComment(int cmt_index) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int re = -1;
		String sql = "";
		
		try {
			con = getConnection();
			sql = "select count(*) from comments where cmt_index=?";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, cmt_index);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				re = rs.getInt(1);
				
			}

		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	
	
	// ��� �� ����
		public int deleteComment(int cmt_index, int cmt_num) {
			Connection con = null;
			PreparedStatement pstmt = null; // �������
			ResultSet rs = null; // �����

			String sql = "";
			
			int re = -1;

			try {
				con = getConnection();
				
			
				sql = "delete comments where cmt_index=? and cmt_num=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, cmt_index);
				pstmt.setInt(2, cmt_num);
					
				re = pstmt.executeUpdate();
				

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("���� ����");
				
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (pstmt != null) {
						pstmt.close();
					}
					if (con != null) {
						con.close();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			return re;

		}
		


		
}
